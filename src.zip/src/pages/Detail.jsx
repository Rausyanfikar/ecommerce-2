import React from 'react';
import Layout from '../components/Layout';
import { BsCart } from 'react-icons/bs';

function Detail() {
  return (
    <Layout>
      <div className="flex justify-center items-center w-full h-screnn">
        <div className="flex justify-center items-center w-full">
          <div>
            <img className=" w-72 h-96" src="https://image.tmdb.org/t/p/w500/fVf4YHHkRfo1uuljpWBViEGmaUQ.jpg" alt="gambar" />
          </div>
          <div className="w-96">
            <p>Nike Air</p>
            <p>Rp.5000.000</p>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis eaque quasi id iste, quaerat voluptates dolore laboriosam, repudiandae asperiores alias officiis ducimus natus at cum! Consectetur illum tempore rem dolorum?
            </p>

            <button className="bg-[#ED7474] justify-center items-center h-16 lg:h-10 hover:bg-pink-900 rounded-md  flex flex-col lg:flex-row mt-2 ">
              <p className="text-lg font-semibold mr-2">Add to Chart</p>

              <p className="text-xl">
                <BsCart />
              </p>
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default Detail;
